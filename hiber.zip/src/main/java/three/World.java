package three;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class World {

    private long id;
    private Set<Parameter> parameters = new HashSet<>();
    private Date creationDate;
    private String name;

    public World() {
        creationDate = new Date();
    }

    public World(String name) {
        this();
        this.name = name;
        parameters.add(new Parameter("population", Type.STRING, name));
    }

    public void setPopulation(Long population) {
        parameters.add(new Parameter("population", Type.LONG, population));
    }

    public void setWeight(Long weight) {
        parameters.add(new Parameter("population", Type.LONG, weight));
    }


    public void addParameter(String name, Type type, String value) {
        parameters.add(new Parameter(name, type, value));
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(Set<Parameter> parameters) {
        this.parameters = parameters;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
