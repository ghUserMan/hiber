package four;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

@SuppressWarnings("ALL")
public class Main {

    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure()
                .buildSessionFactory();

        try {
            persistWorld(sessionFactory);
            loadWorld(sessionFactory);
        } finally {
            sessionFactory.close();
        }
    }

    private static void persistWorld(SessionFactory sessionFactory) {
        System.out.println("-- START PERSIST --");
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        World world = new World("Earth");
        world.setWeight(1000000000L);
        world.setPopulation(70000000000L);
        world.addParameter("first-man", Type.STRING, "Юра");
        System.out.println("- before persist: " + world);
        session.saveOrUpdate(world); //не работает
        System.out.println("- after persist: " + world);

        session.getTransaction().commit();
        session.close();
        System.out.println("-- STOP PERSIST --");
    }

    private static void loadWorld(SessionFactory sessionFactory) {
        System.out.println("-- START LOADING --");
        Session session = sessionFactory.openSession();

        List<World> emps = session.createQuery("from World", World.class).list();
        emps.forEach((x) -> System.out.printf("- %s%n", x));

        session.close();
        System.out.println("-- STOP LOADING --");
    }



    private static void persistParameter(SessionFactory sessionFactory) {
        System.out.println("-- START PERSIST --");
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Parameter parameter = new Parameter("simple-name", Type.STRING, "some-value");
        System.out.println("- before persist: " + parameter);
        session.saveOrUpdate(parameter);
        System.out.println("- after persist: " + parameter);

        session.getTransaction().commit();
        session.close();
        System.out.println("-- STOP PERSIST --");
    }

    private static void loadParameter(SessionFactory sessionFactory) {
        System.out.println("-- START LOADING --");
        Session session = sessionFactory.openSession();

        List<Parameter> emps = session.createQuery("from Parameter", Parameter.class).list();
        emps.forEach((x) -> System.out.printf("- %s%n", x));

        session.close();
        System.out.println("-- STOP LOADING --");
    }





    private static void persistTypeDefinition(SessionFactory sessionFactory) {
        System.out.println("-- START PERSIST --");
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        TypeDefinition td = new TypeDefinition("simple-type", Type.STRING);
        System.out.println("- before persist: " + td);
        session.saveOrUpdate(td);
        System.out.println("- after persist: " + td);

        session.getTransaction().commit();
        session.close();
        System.out.println("-- STOP PERSIST --");
    }

    private static void loadTypeDefinition(SessionFactory sessionFactory) {
        System.out.println("-- START LOADING --");
        Session session = sessionFactory.openSession();

        List<TypeDefinition> emps = session.createQuery("from TypeDefinition", TypeDefinition.class).list();
        emps.forEach((x) -> System.out.printf("- %s%n", x));

        session.close();
        System.out.println("-- STOP LOADING --");
    }

}
