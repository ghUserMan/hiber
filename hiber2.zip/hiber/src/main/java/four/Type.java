package four;

public enum Type {

    LONG,
    STRING

}
