package four;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class World {

    public static final String WEIGHT = "weight";
    public static final String NAME = "name";
    private long id;
    private Map<String, Parameter> parameters = new HashMap<>();
    private Date creationDate;
    private String name;

    private static String POPULATION_NAME = "population";

    public World() {
        creationDate = new Date();
    }

    public World(String name) {
        this();
        this.name = name;
        parameters.put(name, new Parameter(NAME, Type.STRING, name));
    }

    public void setPopulation(Long population) {
        parameters.put(POPULATION_NAME, new Parameter(POPULATION_NAME, Type.LONG, population));
    }

    public void setWeight(Long weight) {
        parameters.put(WEIGHT, new Parameter(WEIGHT, Type.LONG, weight));
    }


    public void addParameter(String name, Type type, String value) {
        parameters.put(name, new Parameter(name, type, value));
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Map<String, Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Parameter> parameters) {
        this.parameters = parameters;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "World{" +
                "id=" + id +
                ", parameters=" + parameters +
                ", creationDate=" + creationDate +
                ", name='" + name + '\'' +
                '}';
    }
}
