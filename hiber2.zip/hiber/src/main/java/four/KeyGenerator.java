package four;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;

public class KeyGenerator  implements IdentifierGenerator {
    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
        TypeDefinition t = (TypeDefinition) object;
        return (long) (t.getName() + t.getType().name()).hashCode();
    }
}
