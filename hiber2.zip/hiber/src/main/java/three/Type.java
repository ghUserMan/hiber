package three;

public enum Type {

    LONG,
    STRING

}
