package three;

public class Parameter {

    private Long id;
    private String name;
    private String value;
    private TypeDefinition type;

    public Parameter() {
    }


    public Parameter(String name, Type type, Long value) {
        this(name, type, String.valueOf(value));
    }

    public Parameter(String name, Type type, String value) {
        this.name = name;
        this.value = value;
        this.type = new TypeDefinition(name, type);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public TypeDefinition getType() {
        return type;
    }

    public void setType(TypeDefinition type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Parameter{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", value='" + value + '\'' +
                ", type=" + type +
                '}';
    }
}
